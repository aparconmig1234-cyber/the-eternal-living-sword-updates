(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const manifests = window.__EEV_LIBRARY_MANIFESTS || {};
  const recordsData = window.__EEV_SEARCH_RECORDS;
  const filtersData = window.__EEV_SEARCH_FILTERS;
  window.__EEV_SEARCH_SHARDS ||= {};
  window.__EEV_ITEMS ||= { spn: {}, eng: {} };

  const productByIdentity = new Map((manifests.spn?.products || []).map(p => [String(p.product_identity_id), p]));
  const loadedScripts = new Map();
  let activeQuery = '';
  let activeResultButton = null;
  const audioCatalog = window.__EEV_AUDIO_CATALOG || {
    counts: { assets_total: 0, installable_now: 0, remote_available_unpinned: 0 },
    by_code: {},
    policy: { explicit_install_selection_required: true, normal_playback_network_allowed: false }
  };
  const audioInstalls = window.__EEV_AUDIO_INSTALLS || { by_code: {} };
  const AUDIO_INSTALL_QUEUE_KEY = 'eternal_living_sword.audio_install_queue.v1';
  const AUDIO_INSTALL_QUEUE_MAX = 100;
  const nativeAudioInstallBridge = window.EEVNativeAudioInstallBridge || null;
  let audioPlayer = null;
  let activeAudioCode = null;
  let activeAudioIdentity = null;

  function loadLocalScript(src) {
    if (loadedScripts.has(src)) return loadedScripts.get(src);
    const promise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('No se pudo abrir un archivo local requerido.'));
      document.head.append(script);
    });
    loadedScripts.set(src, promise);
    return promise;
  }

  function normalizeIndexTerm(raw) {
    const term = String(raw ?? '').trim().toLocaleLowerCase('es');
    if (!term || /\s/u.test(term) || term.includes('*')) throw new Error('Término exacto inválido.');
    return term;
  }

  function querySpec(raw) {
    const query = String(raw ?? '').trim().replace(/\s+/gu, ' ').toLocaleLowerCase('es');
    if (!query) throw new Error('Escribe una palabra o frase.');
    if (query.endsWith('*') && !query.slice(0, -1).includes('*') && !/\s/u.test(query.slice(0, -1))) {
      const prefix = query.slice(0, -1);
      if (!prefix) throw new Error('Escribe letras antes del comodín.');
      return { mode: 'prefix_wildcard', query: prefix + '*', prefix };
    }
    if (query.includes('*')) throw new Error('Por ahora el comodín validado se usa al final: palabra*');
    if (/\s/u.test(query)) return { mode: 'exact_phrase', query, terms: query.split(' ') };
    return { mode: 'exact_term', query, term: query };
  }

  function populateFilters() {
    const yearSelect = $('year-filter');
    const seriesSelect = $('series-filter');
    for (const row of filtersData?.years || []) {
      const option = document.createElement('option');
      option.value = String(row.value);
      option.textContent = String(row.label || row.value);
      yearSelect.append(option);
    }
    for (const row of filtersData?.series || []) {
      const option = document.createElement('option');
      option.value = String(row.series_id);
      option.textContent = String(row.series_name);
      seriesSelect.append(option);
    }
  }

  function activeFilters() {
    return {
      year: $('year-filter')?.value || '',
      series: $('series-filter')?.value || ''
    };
  }

  function applyActiveFilters(query) {
    const selected = activeFilters();
    if (!selected.year && !selected.series) return { ...query, filters: selected };
    const results = query.results.filter(result => {
      const meta = filtersData?.product_filters?.[String(result.product_identity_id)];
      if (!meta) throw new Error('Falta metadata local de filtro para un resultado.');
      if (selected.year && String(meta.year || '') !== selected.year) return false;
      if (selected.series && !(meta.series || []).map(String).includes(selected.series)) return false;
      return true;
    });
    return {
      ...query,
      filters: selected,
      results,
      concordance_count: results.length,
      physical_occurrence_count: results.reduce((sum, row) => sum + Number(row.frequency || 0), 0)
    };
  }

  function activeFilterDescription() {
    const selected = activeFilters();
    const labels = [];
    if (selected.year) labels.push('Año ' + ($('year-filter').selectedOptions[0]?.textContent || selected.year));
    if (selected.series) labels.push('Serie: ' + ($('series-filter').selectedOptions[0]?.textContent || selected.series));
    return labels.join(' · ');
  }

  function shardForTerm(raw) {
    const term = normalizeIndexTerm(raw);
    return new TextEncoder().encode(term)[0].toString(16).padStart(2, '0');
  }

  function findTermEntry(shardData, raw) {
    const term = normalizeIndexTerm(raw);
    const entries = shardData?.entries;
    if (!Array.isArray(entries)) return null;
    let lo = 0, hi = entries.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const value = entries[mid][0];
      if (value === term) return entries[mid];
      if (value < term) lo = mid + 1;
      else hi = mid - 1;
    }
    return null;
  }

  function queryExactTerm(shardData, raw) {
    const term = normalizeIndexTerm(raw);
    const entry = findTermEntry(shardData, term);
    if (!entry) return { term, concordance_count: 0, physical_occurrence_count: 0, results: [] };

    const [storedTerm, docFreq, termFreq, postings] = entry;
    if (storedTerm !== term || postings.length !== docFreq) throw new Error('Índice local inconsistente.');
    const results = postings.map(([docId, frequency]) => {
      const row = recordsData?.records?.[String(docId)];
      if (!row) throw new Error('Mapa local de registros incompleto.');
      const mapped = Object.fromEntries(recordsData.columns.map((name, i) => [name, row[i]]));
      return { doc_id: docId, frequency, ...mapped };
    });
    if (results.reduce((sum, row) => sum + row.frequency, 0) !== termFreq) throw new Error('Frecuencia local inconsistente.');
    return { term, concordance_count: docFreq, physical_occurrence_count: termFreq, results };
  }

  function queryPrefixTerm(shardData, raw) {
    const spec = querySpec(raw);
    if (spec.mode !== 'prefix_wildcard') throw new Error('Consulta de prefijo inválida.');
    const entries = shardData?.entries;
    if (!Array.isArray(entries)) throw new Error('Shard inválido.');
    let lo = 0, hi = entries.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (entries[mid][0] < spec.prefix) lo = mid + 1;
      else hi = mid;
    }
    const byDoc = new Map();
    const matchedTerms = [];
    let physical = 0;
    for (let i = lo; i < entries.length; i++) {
      const [term, docFreq, termFreq, postings] = entries[i];
      if (!term.startsWith(spec.prefix)) break;
      if (!Array.isArray(postings) || postings.length !== docFreq) throw new Error('Postings incompletos.');
      const counted = postings.reduce((sum, row) => sum + row[1], 0);
      if (counted !== termFreq) throw new Error('Frecuencia de prefijo inconsistente.');
      matchedTerms.push(term);
      physical += termFreq;
      for (const [docId, frequency] of postings) byDoc.set(docId, (byDoc.get(docId) || 0) + frequency);
    }
    const results = [...byDoc.entries()].sort((a,b) => a[0] - b[0]).map(([docId, frequency]) => {
      const row = recordsData?.records?.[String(docId)];
      if (!row) throw new Error('Mapa local de registros incompleto.');
      const mapped = Object.fromEntries(recordsData.columns.map((name, i) => [name, row[i]]));
      return { doc_id:docId, frequency, ...mapped };
    });
    return {
      term: spec.query,
      mode: spec.mode,
      matched_terms: matchedTerms,
      concordance_count: results.length,
      physical_occurrence_count: physical,
      results
    };
  }

  function foldSearchText(text) {
    const source = String(text ?? '');
    let normalized = '', offsets = [];
    for (let i = 0; i < source.length;) {
      const cp = source.codePointAt(i);
      const ch = String.fromCodePoint(cp);
      const width = ch.length;
      let folded = ch.toLocaleLowerCase('es');
      if (/\s/u.test(ch)) folded = ' ';
      for (const out of folded) {
        if (out === ' ' && (!normalized || normalized.endsWith(' '))) continue;
        normalized += out;
        offsets.push(i);
      }
      i += width;
    }
    if (normalized.endsWith(' ')) { normalized = normalized.slice(0, -1); offsets.pop(); }
    return { normalized, offsets };
  }

  function findMatches(text, rawQuery) {
    const source = String(text ?? '');
    const map = foldSearchText(source);
    const spec = querySpec(rawQuery);
    const needle = spec.mode === 'prefix_wildcard' ? spec.prefix : spec.query;
    const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const startsWord = /^[\p{L}\p{N}_]/u.test(needle);
    const endsWord = /[\p{L}\p{N}_]$/u.test(needle);
    const left = startsWord ? '(?<![\\p{L}\\p{N}_])' : '';
    const right = spec.mode === 'prefix_wildcard'
      ? '[\\p{L}\\p{N}_]*(?![\\p{L}\\p{N}_])'
      : (endsWord ? '(?![\\p{L}\\p{N}_])' : '');
    const regex = new RegExp(left + escaped + right, 'gu');
    const hits = [];
    let match;
    while ((match = regex.exec(map.normalized)) !== null) {
      const start = map.offsets[match.index] ?? 0;
      const endNorm = match.index + match[0].length - 1;
      const endStart = map.offsets[endNorm] ?? start;
      const lastCp = source.codePointAt(endStart);
      const end = endStart + String.fromCodePoint(lastCp).length;
      hits.push({ start, end });
      if (match[0].length === 0) regex.lastIndex++;
    }
    return hits;
  }

  function whitespaceMap(text) {
    let normalized = '', offsets = [];
    for (let i = 0; i < text.length; i++) {
      const c = /\s/.test(text[i]) ? ' ' : /[‘’]/.test(text[i]) ? "'" : /[“”]/.test(text[i]) ? '"' : text[i];
      if (c === ' ' && (!normalized || normalized.endsWith(' '))) continue;
      normalized += c; offsets.push(i);
    }
    if (normalized.endsWith(' ')) { normalized = normalized.slice(0, -1); offsets.pop(); }
    return { normalized, offsets };
  }

  function expandParagraphTerms(values = []) {
    return values.flatMap(value => String(value).trim().split(/\s+/u)).filter(Boolean);
  }

  function findParagraphAnchors(plainText, paragraphs) {
    const source = whitespaceMap(plainText);
    let from = 0;
    const anchors = [];
    for (const p of paragraphs) {
      const needle = whitespaceMap(p.text).normalized;
      const reference = p.reference.trim();
      if (!reference || !needle || !needle.startsWith(reference)) throw new Error('Referencia de párrafo no verificable.');
      const index = source.normalized.indexOf(needle, from);
      if (index < 0 || source.normalized.indexOf(needle, index + 1) >= 0) throw new Error('Párrafo sin correspondencia única.');
      anchors.push({ reference, offset: source.offsets[index] });
      from = index + needle.length;
    }
    return anchors;
  }

  function mergeNativeParagraphAnchors(printedAnchors, paragraphTerms = []) {
    const indexed = expandParagraphTerms(paragraphTerms);
    const printed = printedAnchors.map(anchor => anchor.reference);
    if (!indexed.length) return printedAnchors;
    if (indexed.length === printed.length && indexed.every((ref, i) => ref === printed[i])) return printedAnchors;
    const implicitStart =
      indexed.length === printed.length + 1 &&
      printed.every((ref, i) => ref === indexed[i + 1]) &&
      (!printedAnchors.length || printedAnchors[0].offset > 0);
    if (implicitStart) return [{ reference: indexed[0], offset: 0, implicit_start: true }, ...printedAnchors];
    throw new Error('Numeración oficial no concuerda con los marcadores impresos.');
  }

  function paragraphReferenceAtOffset(anchors, offset, fallback = null) {
    let current = fallback;
    for (const anchor of anchors) {
      if (anchor.offset > offset) break;
      current = anchor.reference;
    }
    return current;
  }

  function paragraphData(record) {
    const template = document.createElement('template');
    template.innerHTML = record.html;
    const paragraphs = [];
    for (const para of template.content.querySelectorAll('p')) {
      const markers = para.querySelectorAll('.pn');
      if (!markers.length) continue;
      if (markers.length !== 1) throw new Error('Marcadores oficiales ambiguos.');
      paragraphs.push({ reference: markers[0].textContent, text: para.textContent });
    }
    return mergeNativeParagraphAnchors(
      findParagraphAnchors(record.plain_text, paragraphs),
      record.paragraph_numbers || []
    );
  }

  function appendRecordText(body, record, anchors, hits) {
    const anchorMap = new Map();
    for (const anchor of anchors) {
      const list = anchorMap.get(anchor.offset) || [];
      list.push(anchor);
      anchorMap.set(anchor.offset, list);
    }
    const boundaries = new Set([0, record.plain_text.length]);
    for (const anchor of anchors) boundaries.add(anchor.offset);
    for (const hit of hits) { boundaries.add(hit.start); boundaries.add(hit.end); }
    const points = [...boundaries].sort((a,b) => a-b);

    for (let i = 0; i < points.length - 1; i++) {
      const start = points[i], end = points[i + 1];
      for (const anchor of anchorMap.get(start) || []) {
        const span = document.createElement('span');
        span.className = 'paragraph-anchor';
        span.dataset.paragraph = anchor.reference;
        span.dataset.recordId = record.record_id;
        span.id = 'p-' + CSS.escape(record.record_id + '-' + anchor.reference);
        body.append(span);
      }
      if (end <= start) continue;
      const text = record.plain_text.slice(start, end);
      const isHit = hits.some(hit => start >= hit.start && start < hit.end);
      if (isHit) {
        const mark = document.createElement('mark');
        mark.className = 'search-hit';
        mark.textContent = text;
        body.append(mark);
      } else {
        body.append(document.createTextNode(text));
      }
    }
    for (const anchor of anchorMap.get(record.plain_text.length) || []) {
      const span = document.createElement('span');
      span.className = 'paragraph-anchor';
      span.dataset.paragraph = anchor.reference;
      span.dataset.recordId = record.record_id;
      body.append(span);
    }
  }

  async function ensureShard(term) {
    const shard = shardForTerm(term);
    if (!window.__EEV_SEARCH_SHARDS[shard]) {
      try { await loadLocalScript('./data/terms/' + shard + '.js'); }
      catch { return null; }
    }
    return window.__EEV_SEARCH_SHARDS[shard] || null;
  }

  async function ensureItem(identity, language = 'spn') {
    const lang = String(language || 'spn').toLowerCase();
    if (!['spn','eng'].includes(lang)) throw new Error('Idioma de texto inválido.');
    const key = String(identity);
    window.__EEV_ITEMS[lang] ||= {};
    if (!window.__EEV_ITEMS[lang][key]) {
      await loadLocalScript('./data/' + lang + '/items/' + encodeURIComponent(key) + '.js');
    }
    const item = window.__EEV_ITEMS[lang][key];
    if (!item) throw new Error('El mensaje local no se pudo abrir en el idioma seleccionado.');
    return item;
  }

  function formatAudioTime(ms) {
    const total = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = total % 60;
    return String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
  }

  function audioEntry(code, profile) {
    return audioInstalls?.by_code?.[String(code)]?.[profile] || null;
  }

  function catalogAudioEntry(code, profile) {
    return audioCatalog?.by_code?.[String(code)]?.[profile] || null;
  }

  function readAudioInstallQueue() {
    try {
      const parsed = JSON.parse(window.localStorage.getItem(AUDIO_INSTALL_QUEUE_KEY) || '[]');
      if (!Array.isArray(parsed)) return [];
      return parsed
        .filter(row => row && row.official_code && ['ENG', 'SPN'].includes(row.language))
        .slice(0, AUDIO_INSTALL_QUEUE_MAX);
    } catch {
      return [];
    }
  }

  function writeAudioInstallQueue(rows) {
    const clean = rows.slice(0, AUDIO_INSTALL_QUEUE_MAX).map(row => ({
      official_code: String(row.official_code),
      product_identity_id: row.product_identity_id ?? null,
      language: String(row.language),
      requested_at: String(row.requested_at)
    }));
    window.localStorage.setItem(AUDIO_INSTALL_QUEUE_KEY, JSON.stringify(clean));
    return clean;
  }

  function queueAudioInstallation(profile) {
    if (!activeAudioCode) throw new Error('Abre un mensaje antes de seleccionar audio.');
    const availability = audioAvailability(activeAudioCode, profile);
    if (availability.state !== 'verified_installable') {
      throw new Error('Ese audio no está habilitado para instalación verificada.');
    }
    const language = profile === 'spn' ? 'SPN' : profile === 'eng' ? 'ENG' : null;
    if (!language) throw new Error('Idioma de audio inválido.');
    const catalog = catalogAudioEntry(activeAudioCode, profile);
    const queue = readAudioInstallQueue();
    const key = activeAudioCode + ':' + language;
    const existing = queue.find(row => row.official_code + ':' + row.language === key);
    if (!existing) {
      if (queue.length >= AUDIO_INSTALL_QUEUE_MAX) throw new Error('La selección local alcanzó el máximo de 100 audios.');
      queue.push({
        official_code: activeAudioCode,
        product_identity_id: catalog?.product_identity_id ?? activeAudioIdentity ?? null,
        language,
        requested_at: new Date().toISOString()
      });
      writeAudioInstallQueue(queue);
    }
    renderAudioAvailability(activeAudioCode);
    $('audio-status').textContent =
      'Audio ' + language + ' seleccionado para instalación. La selección es local y no descarga ni reproduce por internet.';
    return readAudioInstallQueue();
  }

  function clearAudioInstallQueue(options = {}) {
    window.localStorage.removeItem(AUDIO_INSTALL_QUEUE_KEY);
    renderAudioAvailability(activeAudioCode);
    if (options.announce !== false) {
      $('audio-status').textContent = 'Selección de instalación limpiada. No se descargó ningún audio.';
    }
    return [];
  }

  function buildAudioInstallRequest() {
    const assets = readAudioInstallQueue().map(row => ({
      official_code: String(row.official_code),
      language: String(row.language)
    }));
    return {
      schema_version: '1.0.0',
      mode: 'explicit',
      assets
    };
  }

  async function installSelectedAudio() {
    const request = buildAudioInstallRequest();
    if (!request.assets.length) throw new Error('No hay audios seleccionados para instalar.');
    if (!nativeAudioInstallBridge?.available?.()) {
      throw new Error('El instalador nativo no está disponible en este contenedor.');
    }

    const installButton = $('audio-install-selected');
    installButton.disabled = true;
    document.documentElement.dataset.audioInstallState = 'installing';
    $('audio-status').textContent =
      'Instalando ' + request.assets.length + (request.assets.length === 1 ? ' audio verificado…' : ' audios verificados…');

    try {
      const response = await nativeAudioInstallBridge.install(request);
      const completed =
        response.status === 'completed' &&
        response.requested_assets === request.assets.length &&
        response.installed_assets === request.assets.length &&
        response.failed_assets === 0;

      if (!completed) {
        throw new Error('El instalador nativo no completó toda la selección.');
      }

      clearAudioInstallQueue({ announce: false });
      document.documentElement.dataset.audioInstallState = 'completed';
      $('audio-status').textContent =
        'Instalación completada y verificada. El lector actualizará únicamente su manifiesto local.';

      if (response.runtime_refresh_required) {
        window.setTimeout(() => window.location.reload(), 0);
      } else {
        renderAudioAvailability(activeAudioCode);
      }
      return response;
    } catch (error) {
      document.documentElement.dataset.audioInstallState = 'failed';
      $('audio-status').textContent = 'No se pudo completar la instalación: ' + error.message;
      renderAudioAvailability(activeAudioCode);
      throw error;
    }
  }

  function audioAvailability(code, profile) {
    if (!code) return { state: 'unknown', label: '—', expected_file_bytes: null };
    if (audioEntry(code, profile)) {
      return { state: 'installed', label: 'Instalado', expected_file_bytes: null };
    }
    const catalog = catalogAudioEntry(code, profile);
    if (catalog?.state === 'verified_installable') {
      return {
        state: 'verified_installable',
        label: 'Disponible para instalar',
        expected_file_bytes: catalog.expected_file_bytes || null
      };
    }
    if (catalog?.state === 'remote_unverified') {
      return { state: 'remote_unverified', label: 'Pendiente de verificación', expected_file_bytes: null };
    }
    return { state: 'unavailable', label: 'No disponible', expected_file_bytes: null };
  }

  function renderAudioAvailability(code) {
    const spn = audioAvailability(code, 'spn');
    const eng = audioAvailability(code, 'eng');
    const spnNode = $('audio-availability-spn');
    const engNode = $('audio-availability-eng');
    spnNode.textContent = 'ES: ' + spn.label;
    engNode.textContent = 'EN: ' + eng.label;
    spnNode.dataset.state = spn.state;
    engNode.dataset.state = eng.state;
    document.documentElement.dataset.audioAvailabilitySpn = spn.state;
    document.documentElement.dataset.audioAvailabilityEng = eng.state;

    const queue = readAudioInstallQueue();
    const queued = new Set(queue.map(row => row.official_code + ':' + row.language));
    const spnButton = $('audio-request-spn');
    const engButton = $('audio-request-eng');
    const installButton = $('audio-install-selected');
    const clearButton = $('audio-request-clear');
    const countNode = $('audio-install-queue-count');
    const nativeAvailable = Boolean(nativeAudioInstallBridge?.available?.());
    const spnKey = String(code || '') + ':SPN';
    const engKey = String(code || '') + ':ENG';
    spnButton.disabled = spn.state !== 'verified_installable';
    engButton.disabled = eng.state !== 'verified_installable';
    spnButton.textContent = queued.has(spnKey) ? 'ES seleccionada' : 'Seleccionar ES para instalar';
    engButton.textContent = queued.has(engKey) ? 'EN seleccionada' : 'Seleccionar EN para instalar';
    installButton.disabled = queue.length === 0 || !nativeAvailable;
    installButton.textContent = nativeAvailable
      ? (queue.length ? 'Instalar selección (' + queue.length + ')' : 'Instalar selección')
      : 'Instalador no disponible';
    clearButton.disabled = queue.length === 0;
    countNode.textContent = queue.length + (queue.length === 1 ? ' audio seleccionado' : ' audios seleccionados');
    document.documentElement.dataset.audioInstallQueueCount = String(queue.length);
    document.documentElement.dataset.audioNativeInstallAvailable = nativeAvailable ? 'true' : 'false';
    return { spn, eng };
  }

  function setAudioButtons(enabled) {
    $('audio-play').disabled = !enabled;
    $('audio-pause').disabled = !enabled;
    $('audio-seek').disabled = !enabled;
    $('audio-rate').disabled = !enabled;
  }

  function refreshAudioClock() {
    const media = $('global-audio');
    const position = Math.max(0, Math.round((Number(media.currentTime) || 0) * 1000));
    const duration = Number.isFinite(media.duration) ? Math.round(media.duration * 1000) : 0;
    $('audio-seek').max = String(duration);
    if (!document.documentElement.dataset.audioSeeking) $('audio-seek').value = String(Math.min(position, duration || position));
    $('audio-time').textContent = formatAudioTime(position) + ' / ' + formatAudioTime(duration);
  }

  function ensureAudioPlayer() {
    if (audioPlayer) return audioPlayer;
    if (!window.EEVPlayerCore) throw new Error('El núcleo local de audio no está disponible.');
    audioPlayer = window.EEVPlayerCore.createGlobalPlayer({
      mediaElement: $('global-audio'),
      storage: window.localStorage
    });
    $('global-audio').addEventListener('timeupdate', refreshAudioClock);
    $('global-audio').addEventListener('loadedmetadata', refreshAudioClock);
    $('global-audio').addEventListener('ended', () => {
      $('audio-status').textContent = 'Reproducción terminada · archivo local.';
      document.documentElement.dataset.audioState = 'ended';
      refreshAudioClock();
    });
    return audioPlayer;
  }

  async function loadAudioProfile(profile) {
    if (!activeAudioCode) return false;
    const installed = audioEntry(activeAudioCode, profile);
    if (!installed) {
      setAudioButtons(false);
      $('audio-status').textContent = 'Audio ' + profile.toUpperCase() + ' no instalado en este dispositivo. No se usará streaming.';
      document.documentElement.dataset.audioReady = '';
      return false;
    }
    const player = ensureAudioPlayer();
    const snapshot = await player.load({
      official_code: activeAudioCode,
      product_identity_id: activeAudioIdentity,
      profile,
      local_path: installed.local_path,
      verified_file_sha256: installed.verified_file_sha256,
      verified_file_bytes: installed.verified_file_bytes
    });
    $('audio-language').value = profile;
    $('audio-rate').value = String(snapshot.session?.rate || 1);
    setAudioButtons(true);
    refreshAudioClock();
    $('audio-status').textContent = 'Audio ' + (profile === 'spn' ? 'español' : 'inglés') + ' instalado · reproducción local lista.';
    document.documentElement.dataset.audioReady = profile;
    document.documentElement.dataset.audioState = snapshot.state;
    document.documentElement.dataset.audioCode = activeAudioCode;
    return true;
  }

  async function configureAudioForCode(code, identity = null) {
    if (audioPlayer) audioPlayer.pause();
    activeAudioCode = code ? String(code) : null;
    activeAudioIdentity = identity;
    const availability = renderAudioAvailability(activeAudioCode);
    const eng = activeAudioCode ? audioEntry(activeAudioCode, 'eng') : null;
    const spn = activeAudioCode ? audioEntry(activeAudioCode, 'spn') : null;
    $('audio-language').querySelector('option[value="eng"]').disabled = !eng;
    $('audio-language').querySelector('option[value="spn"]').disabled = !spn;
    document.documentElement.dataset.audioReady = '';
    document.documentElement.dataset.audioCode = activeAudioCode || '';
    if (!eng && !spn) {
      setAudioButtons(false);
      $('audio-seek').value = '0';
      $('audio-seek').max = '0';
      $('audio-time').textContent = '00:00 / 00:00';
      if (!activeAudioCode) {
        $('audio-status').textContent = 'Abre un mensaje para comprobar si su audio está instalado.';
      } else if ([availability.spn.state, availability.eng.state].includes('verified_installable')) {
        $('audio-status').textContent =
          'Audio no instalado · hay un activo verificado disponible para instalar. Reproducir no lo descargará automáticamente.';
      } else if ([availability.spn.state, availability.eng.state].includes('remote_unverified')) {
        $('audio-status').textContent =
          'Audio oficial identificado, todavía no habilitado para instalación verificada. No se intentará transmitirlo.';
      } else {
        $('audio-status').textContent =
          'Este mensaje no tiene audio disponible localmente. No se intentará transmitirlo.';
      }
      return false;
    }
    const preferred = spn ? 'spn' : 'eng';
    return loadAudioProfile(preferred);
  }

  $('audio-play').addEventListener('click', async () => {
    try {
      const snapshot = await ensureAudioPlayer().play();
      $('audio-status').textContent = 'Reproduciendo desde almacenamiento local.';
      document.documentElement.dataset.audioState = snapshot.state;
    } catch (error) {
      $('audio-status').textContent = 'No se pudo reproducir el audio local: ' + error.message;
      document.documentElement.dataset.audioError = 'true';
    }
  });
  $('audio-pause').addEventListener('click', () => {
    if (!audioPlayer) return;
    const snapshot = audioPlayer.pause();
    $('audio-status').textContent = 'Pausa · posición guardada localmente.';
    document.documentElement.dataset.audioState = snapshot.state;
    refreshAudioClock();
  });
  $('audio-seek').addEventListener('pointerdown', () => { document.documentElement.dataset.audioSeeking = 'true'; });
  $('audio-seek').addEventListener('pointerup', () => { delete document.documentElement.dataset.audioSeeking; });
  $('audio-seek').addEventListener('change', () => {
    if (!audioPlayer) return;
    const snapshot = audioPlayer.seek(Number($('audio-seek').value));
    document.documentElement.dataset.audioState = snapshot.state;
    refreshAudioClock();
  });
  $('audio-rate').addEventListener('change', () => {
    if (!audioPlayer) return;
    audioPlayer.setRate(Number($('audio-rate').value));
    $('audio-status').textContent = 'Velocidad guardada · reproducción local.';
  });
  $('audio-language').addEventListener('change', () => {
    loadAudioProfile($('audio-language').value).catch(error => {
      $('audio-status').textContent = 'No se pudo abrir el audio local: ' + error.message;
      document.documentElement.dataset.audioError = 'true';
    });
  });
  $('audio-request-spn').addEventListener('click', () => {
    try {
      queueAudioInstallation('spn');
    } catch (error) {
      $('audio-status').textContent = error.message;
    }
  });
  $('audio-request-eng').addEventListener('click', () => {
    try {
      queueAudioInstallation('eng');
    } catch (error) {
      $('audio-status').textContent = error.message;
    }
  });
  $('audio-install-selected').addEventListener('click', () => {
    installSelectedAudio().catch(() => {});
  });
  $('audio-request-clear').addEventListener('click', () => {
    clearAudioInstallQueue();
  });

  window.__EEV_APP_AUDIO = Object.freeze({
    selectCode: (code, identity = null) => configureAudioForCode(code, identity),
    play: () => ensureAudioPlayer().play(),
    pause: () => audioPlayer?.pause(),
    seek: ms => audioPlayer?.seek(ms),
    snapshot: () => audioPlayer?.snapshot() || null,
    availability: code => ({
      spn: audioAvailability(code, 'spn'),
      eng: audioAvailability(code, 'eng')
    }),
    queueInstallation: profile => queueAudioInstallation(profile),
    installQueue: () => readAudioInstallQueue(),
    installRequest: () => buildAudioInstallRequest(),
    installSelected: () => installSelectedAudio(),
    nativeInstallAvailable: () => Boolean(nativeAudioInstallBridge?.available?.()),
    clearInstallQueue: () => clearAudioInstallQueue(),
    installQueueMax: AUDIO_INSTALL_QUEUE_MAX,
    history: () => audioPlayer?.getHistory() || []
  });

  window.__EEV_APP_READER = Object.freeze({
    openProduct: (identity, language = 'spn') => openProductDirect(identity, language),
    languages: () => ({
      spn: manifests.spn?.products?.length || 0,
      eng: manifests.eng?.products?.length || 0
    })
  });

  function clearReader() {
    $('reading').replaceChildren();
    $('reader-code').textContent = 'Selecciona una concordancia';
    $('reader-title').textContent = 'El mensaje se abrirá aquí';
    $('reader-meta').textContent = '';
    $('reader-status').textContent = 'La búsqueda y la lectura usan solamente archivos instalados.';
    $('reader-start').disabled = true;
    configureAudioForCode(null).catch(() => {});
  }

  function renderSearchResults(query) {
    const resultsBox = $('results');
    resultsBox.replaceChildren();
    $('search-summary').hidden = false;
    const filterDescription = activeFilterDescription();
    $('search-summary').innerHTML =
      query.concordance_count + ' concordancias' +
      '<small>' + query.physical_occurrence_count + ' apariciones físicas en el índice oficial' +
      (filterDescription ? ' · ' + filterDescription : '') + '</small>';

    if (!query.results.length) {
      const empty = document.createElement('p');
      empty.className = 'status';
      empty.textContent = 'No hay concordancias para esta palabra.';
      resultsBox.append(empty);
      return;
    }

    for (const result of query.results) {
      const product = productByIdentity.get(String(result.product_identity_id));
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'result-button';
      button.dataset.identity = String(result.product_identity_id);
      button.dataset.recordId = String(result.record_id);
      button.innerHTML =
        '<span class="result-code"></span>' +
        '<span class="result-title"></span>' +
        '<span class="result-meta"></span>';
      button.querySelector('.result-code').textContent = result.product_id;
      button.querySelector('.result-title').textContent = product?.title || result.product_id;
      button.querySelector('.result-meta').textContent =
        result.frequency + (result.frequency === 1 ? ' aparición en este resultado' : ' apariciones en este resultado');
      button.addEventListener('click', () => openResult(result, button));
      resultsBox.append(button);
    }
  }

  async function queryExactPhrase(spec) {
    const uniqueTerms = [...new Set(spec.terms)];
    const termQueries = [];
    for (const term of uniqueTerms) {
      const shardData = await ensureShard(term);
      if (!shardData) return { term:spec.query, mode:spec.mode, concordance_count:0, physical_occurrence_count:0, results:[] };
      const q = queryExactTerm(shardData, term);
      if (!q.results.length) return { term:spec.query, mode:spec.mode, concordance_count:0, physical_occurrence_count:0, results:[] };
      termQueries.push(q);
    }

    termQueries.sort((a,b) => a.results.length - b.results.length);
    const allowed = termQueries.slice(1).map(q => new Set(q.results.map(r => Number(r.doc_id))));
    const candidates = termQueries[0].results.filter(row => allowed.every(set => set.has(Number(row.doc_id))));
    const identities = [...new Set(candidates.map(row => String(row.product_identity_id)))];
    await Promise.all(identities.map(identity => ensureItem(identity)));

    const results = [];
    let physical = 0;
    for (const row of candidates) {
      const item = window.__EEV_ITEMS.spn[String(row.product_identity_id)];
      const record = item?.records?.find(r => String(r.record_id) === String(row.record_id));
      if (!record) throw new Error('Candidato de frase ausente de la biblioteca instalada.');
      const frequency = findMatches(record.plain_text, spec.query).length;
      if (!frequency) continue;
      physical += frequency;
      results.push({ ...row, frequency });
    }
    results.sort((a,b) => Number(a.doc_id) - Number(b.doc_id));
    return {
      term:spec.query,
      mode:spec.mode,
      concordance_count:results.length,
      physical_occurrence_count:physical,
      results
    };
  }

  async function runSearch(raw) {
    const spec = querySpec(raw);
    activeQuery = spec.query;
    $('search-button').disabled = true;
    $('search-status').textContent = 'Buscando en la biblioteca local…';
    try {
      let query;
      if (spec.mode === 'exact_term') {
        const shardData = await ensureShard(spec.term);
        query = shardData ? queryExactTerm(shardData, spec.term) :
          { term:spec.query, mode:spec.mode, concordance_count:0, physical_occurrence_count:0, results:[] };
      } else if (spec.mode === 'prefix_wildcard') {
        const shardData = await ensureShard(spec.prefix);
        query = shardData ? queryPrefixTerm(shardData, spec.query) :
          { term:spec.query, mode:spec.mode, concordance_count:0, physical_occurrence_count:0, results:[] };
      } else {
        query = await queryExactPhrase(spec);
      }
      query = applyActiveFilters(query);
      renderSearchResults(query);
      const modeLabel = spec.mode === 'exact_phrase' ? 'frase exacta' :
        spec.mode === 'prefix_wildcard' ? 'comodín de prefijo' : 'palabra exacta';
      $('search-status').textContent = query.concordance_count
        ? 'Resultados de ' + modeLabel + ' obtenidos sin consultar internet.'
        : 'La búsqueda no aparece en el índice/biblioteca local.';
      document.documentElement.dataset.lastSearch = spec.query;
      document.documentElement.dataset.lastSearchMode = spec.mode;
    } finally {
      $('search-button').disabled = false;
    }
  }

  async function openProductDirect(identity, language = 'spn') {
    const lang = String(language || 'spn').toLowerCase();
    $('reader-status').textContent = 'Abriendo mensaje desde la biblioteca local…';
    const item = await ensureItem(identity, lang);
    activeQuery = '';
    if (activeResultButton) activeResultButton.removeAttribute('aria-current');
    activeResultButton = null;
    $('reader-code').textContent = item.official_code;
    $('reader-title').textContent = item.title;
    $('reader-meta').textContent = (lang === 'eng' ? 'Inglés' : 'Español') + ' · biblioteca local';
    $('reading').replaceChildren();
    $('reader-start').disabled = false;

    for (const record of item.records) {
      const section = document.createElement('section');
      section.className = 'text-block';
      section.dataset.recordId = record.record_id;
      const body = document.createElement('p');
      body.className = 'exact-text';
      appendRecordText(body, record, paragraphData(record), []);
      section.append(body);
      $('reading').append(section);
    }

    configureAudioForCode(item.official_code, item.product_identity_id).catch(error => {
      $('audio-status').textContent = 'No se pudo abrir el audio local: ' + error.message;
      document.documentElement.dataset.audioError = 'true';
    });

    $('reader-status').textContent = 'Mensaje abierto desde la biblioteca local · texto oficial instalado.';
    $('reading').scrollTop = 0;
    document.documentElement.dataset.directOpenIdentity = String(item.product_identity_id);
    document.documentElement.dataset.directOpenCode = String(item.official_code);
    document.documentElement.dataset.directOpenLanguage = lang;
    return {
      official_code: item.official_code,
      product_identity_id: item.product_identity_id,
      title: item.title,
      records: item.records.length,
      language: lang
    };
  }

  async function openResult(result, button) {
    if (activeResultButton) activeResultButton.removeAttribute('aria-current');
    activeResultButton = button;
    button.setAttribute('aria-current', 'true');
    $('reader-status').textContent = 'Abriendo el mensaje instalado…';

    try {
      const item = await ensureItem(result.product_identity_id);
      $('reader-code').textContent = item.official_code;
      $('reader-title').textContent = item.title;
      $('reader-meta').textContent = 'Español · biblioteca local';
      configureAudioForCode(item.official_code, item.product_identity_id).catch(error => {
        $('audio-status').textContent = 'No se pudo abrir el audio local: ' + error.message;
        document.documentElement.dataset.audioError = 'true';
      });
      $('reading').replaceChildren();
      $('reader-start').disabled = false;

      let carriedParagraphReference = null;
      let targetBlock = null;
      let targetAnchor = null;
      let targetParagraph = null;
      let targetOffset = 0;
      let highlighted = 0;

      for (const record of item.records) {
        const anchors = paragraphData(record);
        const fallback = carriedParagraphReference;
        if (anchors.length) carriedParagraphReference = anchors[anchors.length - 1].reference;
        const hits = findMatches(record.plain_text, activeQuery);
        highlighted += hits.length;

        const section = document.createElement('section');
        section.className = 'text-block';
        section.dataset.recordId = record.record_id;
        const body = document.createElement('p');
        body.className = 'exact-text';
        appendRecordText(body, record, anchors, hits);
        section.append(body);
        $('reading').append(section);

        if (String(record.record_id) === String(result.record_id)) {
          section.classList.add('target-record');
          targetBlock = section;
          const first = hits[0];
          targetOffset = first?.start || 0;
          targetParagraph = first ? paragraphReferenceAtOffset(anchors, first.start, fallback) : fallback;
          if (targetParagraph != null) {
            targetAnchor = [...section.querySelectorAll('.paragraph-anchor')]
              .find(a => a.dataset.paragraph === String(targetParagraph)) || null;
          }
        }
      }

      if (!targetBlock) throw new Error('El registro de concordancia no existe en el mensaje instalado.');
      if (highlighted < result.frequency) throw new Error('El texto instalado no reproduce la frecuencia del índice.');

      requestAnimationFrame(() => {
        (targetAnchor || targetBlock).scrollIntoView({ block: 'start' });
        if (!targetAnchor && targetOffset > 0) {
          targetBlock.dataset.targetOffset = String(targetOffset);
        }
      });

      $('reader-status').textContent = targetParagraph != null
        ? 'Concordancia abierta · párrafo ' + targetParagraph + ' · término resaltado en amarillo.'
        : 'Concordancia abierta · sin número oficial de párrafo · término resaltado en amarillo.';
      document.documentElement.dataset.openRecord = String(result.record_id);
      document.documentElement.dataset.openParagraph = targetParagraph == null ? '' : String(targetParagraph);
    } catch (error) {
      $('reader-status').textContent = 'No se pudo abrir el resultado: ' + error.message;
      document.documentElement.dataset.readerError = 'true';
    }
  }

  $('search-form').addEventListener('submit', event => {
    event.preventDefault();
    $('search-status').textContent = '';
    runSearch($('query').value).catch(error => {
      $('search-status').textContent = error.message;
      $('search-button').disabled = false;
    });
  });
  for (const id of ['year-filter','series-filter']) {
    $(id).addEventListener('change', () => {
      if (!activeQuery) return;
      runSearch(activeQuery).catch(error => {
        $('search-status').textContent = error.message;
        $('search-button').disabled = false;
      });
    });
  }
  $('reader-start').addEventListener('click', () => { $('reading').scrollTop = 0; });
  $('reader-back-results').addEventListener('click', () => {
    $('search-panel')?.scrollIntoView({ block:'start' });
    $('query').focus();
  });

  if (!manifests.spn?.products?.length || !recordsData?.records || !Array.isArray(recordsData.columns) ||
      !filtersData?.product_filters || !Array.isArray(filtersData.years) || !Array.isArray(filtersData.series)) {
    $('search-status').textContent = 'La instalación local está incompleta.';
    document.documentElement.dataset.appError = 'true';
  } else {
    populateFilters();
    clearReader();
    $('search-status').textContent = manifests.spn.products.length + ' obras/mensajes con texto español · ' +
      filtersData.years.length + ' años · ' + filtersData.series.length + ' series · índice local listo.';
    document.documentElement.dataset.appReady = 'true';
  }
})();
