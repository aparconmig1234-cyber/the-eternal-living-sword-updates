(() => {
  // Canal ligero: sólo superposición visual verificada; nunca modifica maestros oficiales.
  'use strict';

  const manifests = window.__EEV_LIBRARY_MANIFESTS || {};
  const products = [...(manifests.spn?.products || [])];
  const englishProducts = [...(manifests.eng?.products || [])];
  const productsByLanguage = { spn: products, eng: englishProducts };

  const drawer = document.getElementById('module-drawer');
  const title = document.getElementById('module-drawer-title');
  const status = document.getElementById('module-drawer-status');
  const body = document.getElementById('module-drawer-body');
  const close = document.getElementById('module-drawer-close');

  const A = './assets/logos/';

  // Microinteracción visual heredada de LOGOS/Replit. No importa ninguna
  // lógica de datos: sólo dibuja el vuelo simbólico cuando una acción real
  // del lector de Mensajes termina correctamente.
  let eagleFlightId = 0;
  let eagleLastAt = 0;

  function launchMessageEagle() {
    const now = Date.now();
    if (now - eagleLastAt < 1200) return false;
    eagleLastAt = now;
    eagleFlightId += 1;

    document.querySelector('.mensajes-aguila-capa')?.remove();
    const layer = document.createElement('div');
    layer.className = 'mensajes-aguila-capa';
    layer.setAttribute('aria-hidden', 'true');
    layer.dataset.flightId = String(eagleFlightId);

    const plumageId = 'eev-aguila-plumaje-' + eagleFlightId;
    const trailId = 'eev-aguila-rastro-' + eagleFlightId;
    layer.innerHTML =
      '<svg class="mensajes-aguila" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">' +
        '<defs>' +
          '<linearGradient id="' + plumageId + '" x1="10" y1="20" x2="110" y2="100" gradientUnits="userSpaceOnUse">' +
            '<stop offset="0%" stop-color="#d9f4eb" stop-opacity=".92"/>' +
            '<stop offset="55%" stop-color="#62b99b" stop-opacity=".78"/>' +
            '<stop offset="100%" stop-color="#e4c36c" stop-opacity=".82"/>' +
          '</linearGradient>' +
          '<linearGradient id="' + trailId + '" x1="0" y1="60" x2="120" y2="60" gradientUnits="userSpaceOnUse">' +
            '<stop offset="0%" stop-color="#6ea6de" stop-opacity="0"/>' +
            '<stop offset="70%" stop-color="#76d0b1" stop-opacity=".58"/>' +
            '<stop offset="100%" stop-color="#e8c96f" stop-opacity=".16"/>' +
          '</linearGradient>' +
        '</defs>' +
        '<path class="mensajes-aguila-rastro" d="M2 66 C 26 60, 44 58, 62 60" stroke="url(#' + trailId + ')" stroke-width="2.4" stroke-linecap="round"/>' +
        '<path d="M60 58c-4.2 0-7 1.9-8.6 4.2-6.1-3.6-13.4-8.3-21.8-14.6-4.6-3.5-9.4-7.7-14.6-12.8 3.9 8.9 8.4 16 13.3 21.4 5 5.5 10.7 9.4 17 11.9-5.2 1.1-10.6 1.4-16.2 1 6.3 3.3 12.4 5.1 18.3 5.5 2.9 4.6 7.1 7.6 12.6 9-1.4-3-2.2-5.9-2.4-8.7 3.4-.9 6.4-2.6 8.9-5.1 5.9-.4 12-2.2 18.3-5.5-5.6.4-11 .1-16.2-1 6.3-2.5 12-6.4 17-11.9 4.9-5.4 9.4-12.5 13.3-21.4-5.2 5.1-10 9.3-14.6 12.8-8.4 6.3-15.7 11-21.8 14.6C67 59.9 64.2 58 60 58z" fill="url(#' + plumageId + ')" opacity=".86"/>' +
      '</svg>';

    document.body.append(layer);
    document.documentElement.dataset.eagleFlightCount = String(eagleFlightId);
    window.setTimeout(() => layer.remove(), 1100);
    return true;
  }

  // Transición puramente visual de Cantos. Conserva la idea del cohete de
  // LOGOS/Replit, pero no trae precarga, audio, navegación ni lógica de origen.
  let rocketVisualId = 0;
  let rocketVisualLastAt = 0;

  function showCantosRocket() {
    const now = Date.now();
    if (now - rocketVisualLastAt < 1200) return false;
    rocketVisualLastAt = now;
    rocketVisualId += 1;

    document.querySelector('.cantos-cohete-capa')?.remove();
    const layer = document.createElement('div');
    layer.className = 'cantos-cohete-capa';
    layer.setAttribute('aria-hidden', 'true');
    layer.dataset.rocketId = String(rocketVisualId);

    const glow = document.createElement('div');
    glow.className = 'cantos-cohete-brillo';
    const trail = document.createElement('div');
    trail.className = 'cantos-cohete-estela';
    const rocket = document.createElement('div');
    rocket.className = 'cantos-cohete-nave';
    rocket.append(
      Object.assign(document.createElement('span'), { className:'cantos-cohete-punta' }),
      Object.assign(document.createElement('span'), { className:'cantos-cohete-ventana' }),
      Object.assign(document.createElement('span'), { className:'cantos-cohete-aleta cantos-cohete-aleta-izq' }),
      Object.assign(document.createElement('span'), { className:'cantos-cohete-aleta cantos-cohete-aleta-der' }),
      Object.assign(document.createElement('span'), { className:'cantos-cohete-llama' })
    );
    layer.append(glow, trail, rocket);
    document.body.append(layer);
    document.documentElement.dataset.rocketVisualCount = String(rocketVisualId);
    window.setTimeout(() => layer.remove(), 1100);
    return true;
  }

  const hubs = {
    israel: {
      title:'Israel y el pueblo judío',
      description:'Historia bíblica, comunidades y fuentes',
      eyebrow:'Cronología profunda sin afirmaciones sin verificar',
      image:A+'israel-historia.jpg',
      skin:'',
      sections:[
        ['✦','Orígenes y patriarcas','Semitas, hebreos, israelitas y patriarcas.'],
        ['♛','Tribus, jueces y reyes','Estructura histórica y referencias bíblicas.'],
        ['⌖','Exilios y diásporas','Cronología y geografía de las dispersiones.'],
        ['◎','Comunidades judías','Ashkenazíes, sefardíes, mizrajíes y otras comunidades.'],
        ['▤','Judaísmo','Tradiciones y contexto documentado.'],
        ['◷','Historia contemporánea','Sionismo, Holocausto, Estado de Israel y retorno.'],
        ['◉','Pueblos y territorios','Contexto histórico y geográfico documentado.'],
        ['◇','Profecías y mensajes WMB','Fuentes bíblicas y citas exactas, nunca inventadas.']
      ]
    },
    jesus: {
      title:'Vida del Señor Jesucristo',
      description:'Cronología y estudio con fuentes bíblicas',
      eyebrow:'Contenido bíblico verificable',
      image:A+'vida-jesucristo.jpg',
      skin:'',
      sections:[
        ['◷','Nacimiento e infancia','Pasajes, lugares y cronología de los Evangelios.'],
        ['⌖','Ministerio público','Recorridos, milagros, parábolas y enseñanzas.'],
        ['▤','Pasión y resurrección','Secuencia de acontecimientos y referencias bíblicas.'],
        ['☷','Comparación de Evangelios','Lectura paralela por episodio y fuente.']
      ]
    },
    wmb: {
      title:'William Marrion Branham',
      description:'Historia y vida documentadas',
      eyebrow:'Archivo biográfico y fuentes originales',
      image:A+'william-branham.jpg',
      skin:'',
      sections:[
        ['◷','Cronología','Etapas de vida organizadas por fecha y fuente.'],
        ['⌖','Lugares','Ciudades y recorridos asociados al archivo histórico.'],
        ['▤','Mensajes','Acceso directo a la biblioteca WMB sin alterar los originales.'],
        ['◉','Audios originales','Grabaciones vinculadas de forma inequívoca.']
      ]
    },
    nube: {
      title:'La Nube / Columna',
      description:'Historia, fuentes y significado',
      eyebrow:'Archivo visual y referencias verificables',
      image:A+'nube-columna.jpg',
      skin:'',
      sections:[
        ['☁','La Nube de 1963','Archivo histórico y cronología.'],
        ['◉','Columna de Fuego','Fotografías y documentación.'],
        ['▤','Mensajes relacionados','Referencias exactas en la biblioteca local.'],
        ['⌕','Fuentes','Material documental y comprobación.']
      ]
    },
    judio: {
      title:'Israel y el Pueblo Judío',
      description:'Comunidades, historia y cronología',
      eyebrow:'Navegación histórica documentada',
      image:A+'mod-judio.jpg',
      skin:'',
      sections:[
        ['◎','Comunidades','Ashkenazíes, sefardíes, mizrajíes y otras comunidades.'],
        ['◷','Cronología','Recorrido histórico organizado por épocas.'],
        ['⌖','Geografía','Pueblos, ciudades y territorios.'],
        ['▤','Fuentes bíblicas','Referencias conectadas con la biblioteca.']
      ]
    },
    investigaciones: {
      title:'Investigaciones importantes',
      description:'Estudios documentados y fuentes verificables',
      eyebrow:'Contenido separado de los maestros oficiales',
      image:A+'logos-celestial-hero.jpg',
      skin:'',
      sections:[
        ['⌕','Investigaciones','Estudios organizados por tema.'],
        ['▤','Documentos','Material de respaldo y referencias.'],
        ['◷','Cronologías','Líneas de tiempo de investigación.'],
        ['✓','Fuentes verificadas','Registro de procedencia y comprobación.']
      ]
    },
    archivo: {
      title:'Archivo VGR',
      description:'Material oficial descargado y organizado',
      eyebrow:'Archivo visual separado de la lógica',
      image:A+'logos-celestial-hero.jpg',
      skin:'',
      sections:[
        ['▣','Fotografías','Colecciones visuales oficiales.'],
        ['▧','Fondos','Recursos gráficos disponibles.'],
        ['◉','Audios','Catálogo de audio vinculado.'],
        ['▤','Documentos','Material de consulta y archivo.']
      ]
    },
    favoritos: {
      title:'Favoritos',
      description:'Accesos guardados',
      eyebrow:'Estructura visual de LOGOS',
      image:A+'portada-portal-familia.jpg',
      skin:'',
      sections:[
        ['☆','Mensajes favoritos','Acceso visual reservado.'],
        ['☆','Pasajes favoritos','Acceso visual reservado.'],
        ['☆','Temas favoritos','Acceso visual reservado.'],
        ['☆','Cantos favoritos','Acceso visual reservado.']
      ]
    },
    cuenta: {
      title:'Cuenta',
      description:'Preferencias y perfil',
      eyebrow:'La aplicación final no dependerá de Replit',
      image:A+'portada-portal-familia.jpg',
      skin:'',
      sections:[
        ['◉','Perfil','Espacio visual del usuario.'],
        ['⚙','Ajustes','Preferencias de la aplicación.'],
        ['⇩','Descargas','Paquetes locales instalados.'],
        ['↻','Actualizaciones','Buscar e instalar correcciones ligeras desde el canal estable de GitHub.'],
        ['?','Ayuda','Información y soporte.']
      ]
    }
  };

  function setDrawerSkin(skin='') {
    if (skin) drawer.dataset.skin = skin;
    else delete drawer.dataset.skin;
  }

  function showDrawer(name, message, skin='') {
    title.textContent = name;
    status.textContent = message;
    body.replaceChildren();
    setDrawerSkin(skin);
    drawer.hidden = false;
    drawer.scrollIntoView({ block:'start' });
    document.documentElement.dataset.openModule = name.toLocaleLowerCase('es');
  }

  function closeDrawer() {
    drawer.hidden = true;
    body.replaceChildren();
    setDrawerSkin('');
    delete document.documentElement.dataset.openModule;
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  const BIBLE_BOOKS = Object.freeze({
    old: [
      ['Gn','Génesis',50],['Ex','Éxodo',40],['Lv','Levítico',27],['Nm','Números',36],['Dt','Deuteronomio',34],
      ['Jos','Josué',24],['Jue','Jueces',21],['Rt','Rut',4],['1 S','1 Samuel',31],['2 S','2 Samuel',24],
      ['1 R','1 Reyes',22],['2 R','2 Reyes',25],['1 Cr','1 Crónicas',29],['2 Cr','2 Crónicas',36],['Esd','Esdras',10],
      ['Neh','Nehemías',13],['Est','Ester',10],['Job','Job',42],['Sal','Salmos',150],['Pr','Proverbios',31],
      ['Ec','Eclesiastés',12],['Cnt','Cantares',8],['Is','Isaías',66],['Jer','Jeremías',52],['Lm','Lamentaciones',5],
      ['Ez','Ezequiel',48],['Dn','Daniel',12],['Os','Oseas',14],['Jl','Joel',3],['Am','Amós',9],
      ['Abd','Abdías',1],['Jon','Jonás',4],['Mi','Miqueas',7],['Nah','Nahúm',3],['Hab','Habacuc',3],
      ['Sof','Sofonías',3],['Hag','Hageo',2],['Zac','Zacarías',14],['Mal','Malaquías',4]
    ],
    new: [
      ['Mt','Mateo',28],['Mr','Marcos',16],['Lc','Lucas',24],['Jn','Juan',21],['Hch','Hechos',28],
      ['Ro','Romanos',16],['1 Co','1 Corintios',16],['2 Co','2 Corintios',13],['Gá','Gálatas',6],['Ef','Efesios',6],
      ['Fil','Filipenses',4],['Col','Colosenses',4],['1 Ts','1 Tesalonicenses',5],['2 Ts','2 Tesalonicenses',3],
      ['1 Ti','1 Timoteo',6],['2 Ti','2 Timoteo',4],['Tit','Tito',3],['Flm','Filemón',1],['He','Hebreos',13],
      ['Stg','Santiago',5],['1 P','1 Pedro',5],['2 P','2 Pedro',3],['1 Jn','1 Juan',5],['2 Jn','2 Juan',1],
      ['3 Jn','3 Juan',1],['Jud','Judas',1],['Ap','Apocalipsis',22]
    ]
  });

  function renderUpdates(config) {
    showDrawer(config.title, 'Actualizaciones · canal estable', '');
    const hub = el('section','visual-hub visual-hub-detail');
    const head = el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand','LA ETERNA ESPADA VIVIENTE'));
    head.append(el('h3','','Actualizaciones'));
    head.append(el('p','','Correcciones pequeñas de interfaz sin volver a descargar toda la aplicación.'));
    hub.append(head);

    const panel = el('div','visual-detail-panel');
    panel.append(el('div','visual-detail-icon','↻'));
    panel.append(el('h4','','Canal estable de GitHub'));
    const info = el('p','visual-detail-note','La aplicación trabaja offline. Sólo se conecta cuando tú pulsas Buscar actualización; verifica el paquete, lo guarda localmente y vuelve a trabajar sin conexión.');
    panel.append(info);

    const state = el('p','module-status','');
    const bridge = window.EEVAndroidUpdater;
    if (!bridge?.getStatus || !bridge?.checkAndApplyUpdate) {
      state.textContent = 'Este control estará disponible en la instalación Android estable.';
    } else {
      try {
        const current = JSON.parse(bridge.getStatus());
        state.textContent = 'Versión nativa ' + current.native_version_name + ' · corrección local ' +
          (current.web_version === '0' ? 'base incluida' : current.web_version) +
          (current.overlay_active ? ' · actualización ligera activa' : '');
      } catch (_) {
        state.textContent = 'Canal de actualización preparado.';
      }
    }
    panel.append(state);

    const actions = el('div','visual-detail-actions');
    const back = el('button','visual-action-button','← Volver a Cuenta');
    back.type='button';
    back.addEventListener('click',()=>renderHub(config,'cuenta'));

    const check = el('button','visual-action-button visual-action-button--primary','Buscar actualización');
    check.type='button';
    check.disabled = !bridge?.checkAndApplyUpdate;
    check.addEventListener('click',()=>{
      try {
        const started = JSON.parse(bridge.checkAndApplyUpdate());
        state.textContent = started.message || 'Comprobando GitHub…';
        check.disabled = true;
        const onResult = event => {
          const result = event.detail || {};
          state.textContent = result.message || result.status || 'Comprobación terminada.';
          check.disabled = false;
          window.removeEventListener('eev-update-result', onResult);
        };
        window.addEventListener('eev-update-result', onResult);
      } catch (error) {
        state.textContent = 'No se pudo iniciar la comprobación: ' + error.message;
        check.disabled = false;
      }
    });

    const restore = el('button','visual-action-button','Restaurar versión incluida');
    restore.type='button';
    restore.disabled = !bridge?.clearOverlay;
    restore.addEventListener('click',()=>{
      if (!bridge?.clearOverlay) return;
      try {
        const result = JSON.parse(bridge.clearOverlay());
        state.textContent = result.message || 'Restaurando la versión incluida…';
      } catch (error) {
        state.textContent = 'No se pudo restaurar: ' + error.message;
      }
    });

    actions.append(back,check,restore);
    panel.append(actions);
    hub.append(panel);
    body.append(hub);
  }

  function renderHubDetail(config, moduleName, sectionIndex) {
    const section = (config.sections || [])[sectionIndex];
    if (!section) return renderHub(config, moduleName);
    const [icon, sectionTitle, sectionDescription] = section;

    if (moduleName === 'cuenta' && sectionTitle === 'Actualizaciones') return renderUpdates(config);
    if (moduleName === 'wmb' && sectionTitle === 'Mensajes') return openMessages();
    if (moduleName === 'wmb' && sectionTitle === 'Audios originales') return openMessages({audioMode:true});

    showDrawer(config.title, sectionTitle + ' · navegación visual operable', '');
    const hub = el('section','visual-hub visual-hub-detail');
    const head = el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand',config.eyebrow || 'LA ETERNA ESPADA VIVIENTE'));
    head.append(el('h3','',sectionTitle));
    head.append(el('p','',sectionDescription));
    hub.append(head);

    const detail = el('div','visual-detail-panel');
    detail.append(el('div','visual-detail-icon',icon));
    detail.append(el('h4','',sectionTitle));
    detail.append(el('p','',sectionDescription));
    detail.append(el('p','visual-detail-note','Esta sección visual ya navega de forma independiente. El contenido documental se conectará únicamente desde fuentes locales/verificadas, sin alterar los maestros oficiales.'));

    const actions = el('div','visual-detail-actions');
    const back = el('button','visual-action-button','← Volver al módulo');
    back.type='button';
    back.addEventListener('click',()=>renderHub(config,moduleName));
    const search = el('button','visual-action-button visual-action-button--primary','Buscar en Mensajes');
    search.type='button';
    search.addEventListener('click',()=>openConcordance(sectionTitle,true));
    actions.append(back,search);
    detail.append(actions);
    hub.append(detail);
    body.append(hub);
  }

  function renderBibleChapters(book, testament) {
    const [abbr, name, chapters] = book;
    showDrawer('Biblia', name + ' · ' + chapters + (chapters === 1 ? ' capítulo' : ' capítulos'), '');
    const hub = el('section','visual-hub visual-bible-chapters');
    const head = el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand',testament === 'old' ? 'ANTIGUO TESTAMENTO' : 'NUEVO TESTAMENTO'));
    head.append(el('h3','',name));
    head.append(el('p','',chapters + (chapters === 1 ? ' capítulo' : ' capítulos') + ' · navegación local'));
    hub.append(head);

    const actions = el('div','visual-detail-actions visual-detail-actions--top');
    const back = el('button','visual-action-button','← Libros');
    back.type='button';
    back.addEventListener('click',()=>renderBible(testament));
    actions.append(back);
    hub.append(actions);

    const grid = el('div','visual-chapter-grid');
    for (let chapter = 1; chapter <= chapters; chapter += 1) {
      const button = el('button','visual-chapter-button',String(chapter));
      button.type='button';
      button.dataset.book=abbr;
      button.dataset.chapter=String(chapter);
      button.setAttribute('aria-label',name + ' capítulo ' + chapter);
      button.addEventListener('click',()=>{
        grid.querySelectorAll('.visual-chapter-button[aria-current="true"]').forEach(node=>node.removeAttribute('aria-current'));
        button.setAttribute('aria-current','true');
        status.textContent = name + ' ' + chapter + ' seleccionado · navegación visual lista; texto bíblico local pendiente de su paquete fuente.';
      });
      grid.append(button);
    }
    hub.append(grid);
    body.append(hub);
  }

  function messageSearchText(product) {
    return [product.official_code, product.title, product.year]
      .filter(Boolean).join(' ').toLocaleLowerCase('es');
  }

  function renderMessageList(query='', options={}) {
    const normalized = String(query || '').trim().toLocaleLowerCase('es');
    const language = options.language === 'eng' ? 'eng' : 'spn';
    const sourceProducts = productsByLanguage[language];
    const cap = options.demo ? 12 : 80;
    const matches = sourceProducts
      .filter(product => !normalized || messageSearchText(product).includes(normalized))
      .slice(0, cap);

    body.querySelector('.message-browser-list')?.remove();

    const list = el('div','message-browser-list');
    list.dataset.resultCount = String(matches.length);

    if (!matches.length) {
      list.append(el('p','module-empty','No hay mensajes que coincidan con esa búsqueda.'));
    }

    for (const product of matches) {
      const button = el('button','message-browser-item');
      button.type = 'button';
      button.dataset.identity = String(product.product_identity_id);
      button.dataset.code = String(product.official_code || '');

      const code = el('span','message-browser-code',product.official_code || '');
      const name = el('strong','',product.title || product.official_code || 'Mensaje');
      const meta = el('span','message-browser-meta',[product.year, language === 'eng' ? 'Texto inglés local' : 'Texto español local'].filter(Boolean).join(' · '));

      button.append(code,name,meta);
      button.addEventListener('click', async () => {
        button.disabled = true;
        try {
          if (!window.__EEV_APP_READER?.openProduct) throw new Error('El lector local no está disponible.');
          await window.__EEV_APP_READER.openProduct(product.product_identity_id, language);
          launchMessageEagle();
          closeDrawer();
          const target = options.audioMode
            ? document.getElementById('audio-panel')
            : document.getElementById('concordancia-workspace');
          target?.scrollIntoView({ block:'start' });
        } catch (error) {
          status.textContent = 'No se pudo abrir el mensaje: ' + error.message;
          button.disabled = false;
        }
      });
      list.append(button);
    }

    body.append(list);
    status.textContent = normalized
      ? matches.length + ' resultados visibles · búsqueda local'
      : options.demo
        ? 'Muestra visual de mensajes · ' + matches.length + ' elementos'
        : sourceProducts.length + ' mensajes/obras con texto ' + (language === 'eng' ? 'inglés' : 'español') + ' · mostrando ' + matches.length;
  }

  function messagesHeader(options={}) {
    const wrap = el('div','logos-messages-visual');
    wrap.append(el('div','logos-rainbow'));
    wrap.append(el('div','logos-book'));
    wrap.append(el('h3','logos-message-title', options.audioMode ? 'REPRODUCIR' : options.demo ? 'DEMO' : 'MENSAJES'));
    wrap.append(el('p','logos-message-subtitle', options.audioMode ? 'AUDIO Y TEXTO DEL MISMO MENSAJE' : 'BIBLIOTECA DE LA PALABRA HABLADA'));
    wrap.append(el('div','logos-message-counter',products.length + ' textos ES · ' + englishProducts.length + ' textos EN locales'));

    const tools = el('div','logos-message-tools');
    const toolDefs=[
      ['Biblioteca','Mensajes instalados'],
      ['Concordancia','Búsqueda en el corpus'],
      ['Audios','Reproducción local'],
      ['Libros','Colecciones y estudios'],
      ['Series','Organización por series'],
      ['Notas','Espacio de estudio'],
      ['Resaltados','Marcadores visuales'],
      ['Descargas','Paquetes locales']
    ];
    toolDefs.forEach(([a,b],i)=>{
      const bt=el('button','logos-message-tool');
      bt.type='button';
      bt.innerHTML='<span>'+a+'</span><small>'+b+'</small>';
      if(i===1) bt.addEventListener('click',()=>openConcordance());
      if(i===2) bt.addEventListener('click',()=>{
        closeDrawer();
        document.getElementById('audio-panel')?.scrollIntoView({block:'start'});
      });
      tools.append(bt);
    });
    wrap.append(tools);
    return wrap;
  }

  function openMessages(options={}) {
    showDrawer(
      options.audioMode ? 'Reproducir mensajes' : options.demo ? 'Mensajes Demo' : 'Mensajes',
      products.length + ' mensajes/obras con texto español disponibles localmente.',
      'mensajes'
    );
    body.append(messagesHeader(options));

    const tools = el('div','message-browser-tools');
    const languageLabel = el('label','', 'Idioma del texto');
    languageLabel.htmlFor='message-browser-language';
    const languageSelect = el('select');
    languageSelect.id='message-browser-language';
    const spnOption=el('option','', 'Español (' + products.length + ')'); spnOption.value='spn';
    const engOption=el('option','', 'Inglés (' + englishProducts.length + ')'); engOption.value='eng';
    languageSelect.append(spnOption,engOption);
    options.language = options.language === 'eng' ? 'eng' : 'spn';
    languageSelect.value = options.language;
    const label = el('label','', 'Buscar por código o título');
    label.htmlFor='message-browser-search';
    const input=el('input');
    input.id='message-browser-search';
    input.type='search';
    input.autocomplete='off';
    input.placeholder='Ej. 65-0220 · Rapto';
    tools.append(languageLabel,languageSelect,label,input);
    body.append(tools);

    renderMessageList('',options);
    languageSelect.addEventListener('change',()=>{
      options.language=languageSelect.value;
      renderMessageList(input.value,options);
    });
    input.addEventListener('input',()=>renderMessageList(input.value,options));
    requestAnimationFrame(()=>input.focus());
  }

  function renderHub(config, moduleName='') {
    showDrawer(config.title,config.description,'');
    const hub=el('section','visual-hub '+(config.skin||''));

    const head=el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand','LA ETERNA ESPADA VIVIENTE'));
    head.append(el('h3','',config.title));
    head.append(el('p','',config.description));
    hub.append(head);

    if(config.image){
      const hero=el('div','visual-hub-hero');
      const img=el('img');
      img.src=config.image;
      img.alt='';
      const caption=el('span','',config.eyebrow||'Contenido documentado');
      hero.append(img,caption);
      hub.append(hero);
    }

    const grid=el('div','visual-hub-grid');
    (config.sections||[]).forEach(([icon,st,sd],index)=>{
      const card=el('button','visual-hub-card visual-hub-card--button');
      card.type='button';
      card.dataset.section=String(index);
      card.setAttribute('aria-label','Abrir ' + st);
      const ico=el('div','visual-hub-icon',icon);
      const copy=el('div');
      copy.append(el('h4','',st),el('p','',sd));
      card.append(ico,copy);
      card.addEventListener('click',()=>renderHubDetail(config,moduleName,index));
      grid.append(card);
    });
    hub.append(grid);
    body.append(hub);
  }

  function renderBible(initialTestament='old') {
    const testament = initialTestament === 'new' ? 'new' : 'old';
    showDrawer('Biblia','66 libros · Antiguo y Nuevo Testamento · navegación visual operable','');
    const hub=el('section','visual-hub');
    const head=el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand','LA ETERNA ESPADA VIVIENTE'));
    head.append(el('h3','','Biblia'));
    head.append(el('p','','66 libros organizados por testamento y capítulo'));
    hub.append(head);

    const top=el('div','visual-bible-top');
    [['Prioridad editorial','Scofield','Estructura preparada para texto, notas y referencias.'],['Comparación prevista','Thompson','Preparada para comparación paralela por versículo.']].forEach(([k,n,d])=>{
      const card=el('article','visual-bible-card');
      card.append(el('small','',k),el('h4','',n),el('p','',d));
      top.append(card);
    });
    hub.append(top);

    const tabs=el('div','visual-tabs');
    const old=el('button','','Antiguo Testamento (39)'); old.type='button';
    const neu=el('button','','Nuevo Testamento (27)'); neu.type='button';
    tabs.append(old,neu); hub.append(tabs);

    const grid=el('div','visual-hub-grid visual-bible-books');
    hub.append(grid);

    const drawBooks=(key)=>{
      old.setAttribute('aria-selected',key==='old'?'true':'false');
      neu.setAttribute('aria-selected',key==='new'?'true':'false');
      grid.replaceChildren();
      for (const book of BIBLE_BOOKS[key]) {
        const [abbr,name,chapters]=book;
        const card=el('button','visual-hub-card visual-hub-card--button visual-bible-book');
        card.type='button';
        card.append(el('div','visual-hub-icon',abbr));
        const cp=el('div');
        cp.append(el('h4','',name),el('p','',chapters + (chapters===1?' capítulo':' capítulos')));
        card.append(cp);
        card.addEventListener('click',()=>renderBibleChapters(book,key));
        grid.append(card);
      }
      status.textContent=(key==='old'?'Antiguo Testamento':'Nuevo Testamento')+' · '+BIBLE_BOOKS[key].length+' libros visibles.';
    };
    old.addEventListener('click',()=>drawBooks('old'));
    neu.addEventListener('click',()=>drawBooks('new'));
    drawBooks(testament);
    body.append(hub);
  }

  function renderStudy() {
    showDrawer('Estudio por temas','Categorías doctrinales · conectado a la concordancia local','');
    const hub=el('section','visual-hub');
    const head=el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand','FUENTES VERIFICABLES'));
    head.append(el('h3','','Estudio por temas'));
    head.append(el('p','','Selecciona un tema para buscarlo inmediatamente en los Mensajes locales.'));
    hub.append(head);

    const topics=[['◆','Deidad','Referencias bíblicas y mensajes.'],['⇧','Rapto','Estudio documentado por fuentes.'],['◈','Sellos','Organización temática.'],['✦','Edades','Cronología y referencias.'],['◎','Israel','Fuentes bíblicas e históricas.'],['▤','Profecía','Citas exactas y documentos.']];
    const search=el('div','visual-search');
    const input=el('input');
    input.type='search';
    input.autocomplete='off';
    input.placeholder='Filtrar temas…';
    search.append(input);
    hub.append(search);

    const grid=el('div','visual-hub-grid');
    const draw=(query='')=>{
      const needle=String(query).trim().toLocaleLowerCase('es');
      grid.replaceChildren();
      const matches=topics.filter(([,n,d])=>!needle||(n+' '+d).toLocaleLowerCase('es').includes(needle));
      if(!matches.length) grid.append(el('p','module-empty','No hay temas visuales que coincidan.'));
      for(const [i,n,d] of matches){
        const card=el('button','visual-hub-card visual-hub-card--button');
        card.type='button';
        card.append(el('div','visual-hub-icon',i));
        const cp=el('div'); cp.append(el('h4','',n),el('p','',d)); card.append(cp);
        card.addEventListener('click',()=>openConcordance(n,true));
        grid.append(card);
      }
      status.textContent=matches.length+' temas visibles · toca uno para buscarlo en la concordancia local.';
    };
    input.addEventListener('input',()=>draw(input.value));
    input.addEventListener('keydown',event=>{
      if(event.key==='Enter' && input.value.trim()){
        event.preventDefault();
        openConcordance(input.value.trim(),true);
      }
    });
    draw('');
    hub.append(grid); body.append(hub);
    requestAnimationFrame(()=>input.focus());
  }

  function renderCantos() {
    showCantosRocket();
    renderHub({
      title:'Cantos',
      description:'Himnos y alabanzas · atmósfera espacial',
      eyebrow:'Central multimedia visual de LOGOS',
      image:A+'mod-cantos.jpg',
      skin:'visual-cantos',
      sections:[
        ['♪','Todos','Biblioteca completa de cantos.'],
        ['▶','Con video','Cantos con material audiovisual.'],
        ['▤','Con letra','Lectura de letras y referencias.'],
        ['☆','Favoritos','Colección personal visual.'],
        ['◎','Centro multimedia','Navegación entre medios.'],
        ['✦','Cantos infantiles','Área visual para contenido infantil.']
      ]
    });
  }

  function renderGlossary() {
    showDrawer('Diccionario y glosario','Términos del corpus y conceptos doctrinales','');
    const hub=el('section','visual-hub');
    const head=el('header','visual-hub-header');
    head.append(el('div','visual-hub-brand','DICCIONARIO Y GLOSARIO'));
    head.append(el('h3','','Diccionario y glosario'));
    head.append(el('p','','Términos del corpus y conceptos doctrinales'));
    hub.append(head);
    const tabs=el('div','visual-tabs');
    const a=el('button','','Diccionario');a.type='button';a.setAttribute('aria-selected','true');
    const b=el('button','','Glosario doctrinal');b.type='button';b.setAttribute('aria-selected','false');
    a.onclick=()=>{a.setAttribute('aria-selected','true');b.setAttribute('aria-selected','false')};
    b.onclick=()=>{a.setAttribute('aria-selected','false');b.setAttribute('aria-selected','true')};
    tabs.append(a,b);hub.append(tabs);
    const search=el('div','visual-search'); const input=el('input'); input.placeholder='Buscar término o concepto…'; search.append(input); hub.append(search);
    const grid=el('div','visual-hub-grid');
    [['EN','Término inglés','Frecuencia y equivalencias.'],['ES','Término español','Formas y referencias.'],['↔','Equivalencias','Relaciones documentadas.'],['▤','Conceptos','Definiciones doctrinales.']].forEach(([i,n,d])=>{const c=el('article','visual-hub-card');c.append(el('div','visual-hub-icon',i));const cp=el('div');cp.append(el('h4','',n),el('p','',d));c.append(cp);grid.append(c)});
    hub.append(grid);body.append(hub);
  }

  function openConcordance(preset='', submit=false) {
    closeDrawer();
    document.getElementById('concordancia-workspace')?.scrollIntoView({block:'start'});
    const query=document.getElementById('query');
    if(query && preset) query.value=String(preset);
    query?.focus();
    if(submit && query?.value.trim()){
      const form=document.getElementById('search-form');
      requestAnimationFrame(()=>form?.requestSubmit());
    }
  }

  function openModule(name) {
    switch(name){
      case 'mensajes': return openMessages();
      case 'solo-leer': return openMessages();
      case 'demo': return openMessages({demo:true});
      case 'reproductor': return openMessages({audioMode:true});
      case 'concordancia': return openConcordance();
      case 'biblia': return renderBible();
      case 'estudio': return renderStudy();
      case 'cantos': return renderCantos();
      case 'glosario': return renderGlossary();
      case 'israel': case 'jesus': case 'wmb': case 'nube': case 'judio':
      case 'investigaciones': case 'archivo': case 'favoritos': case 'cuenta':
        return renderHub(hubs[name],name);
      default: throw new Error('Módulo visual desconocido: '+name);
    }
  }

  document.querySelectorAll('[data-module]').forEach(control=>{
    control.addEventListener('click',()=>openModule(control.dataset.module));
  });

  document.querySelectorAll('[data-shell-nav]').forEach(control=>{
    control.addEventListener('click',()=>{
      const name=control.dataset.shellNav;
      if(name==='inicio'){
        closeDrawer();
        document.getElementById('inicio')?.scrollIntoView({block:'start'});
      } else if(name==='buscar') {
        openConcordance();
      } else {
        openModule(name);
      }
    });
  });

  close?.addEventListener('click',closeDrawer);

  window.__EEV_VISUAL_SHELL=Object.freeze({
    openMessages,
    openModule,
    closeModule:closeDrawer,
    moduleCount:document.querySelectorAll('[data-module]').length,
    messageProductCount:products.length,
    englishMessageProductCount:englishProducts.length,
    sourceVisual:'LOGOS/Replit',
    launchMessageEagle,
    eagleEffectImported:true,
    showCantosRocket,
    rocketEffectImported:true,
    logicImported:false
  });

  document.documentElement.dataset.visualShellReady='true';
})();
