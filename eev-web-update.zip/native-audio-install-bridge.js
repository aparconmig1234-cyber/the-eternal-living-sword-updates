(() => {
  'use strict';

  const MAX_ASSETS = 100;
  const LANGUAGES = new Set(['ENG', 'SPN']);
  const ALLOWED_REQUEST_KEYS = new Set(['schema_version', 'mode', 'assets']);
  const ALLOWED_ASSET_KEYS = new Set(['official_code', 'language']);
  const ALLOWED_RESPONSE_KEYS = new Set([
    'schema_version',
    'status',
    'requested_assets',
    'installed_assets',
    'failed_assets',
    'runtime_refresh_required'
  ]);
  const ALLOWED_STATUSES = new Set(['accepted', 'completed', 'failed']);

  function sameKeys(value, allowed) {
    const keys = Object.keys(value || {});
    return keys.length === allowed.size && keys.every(key => allowed.has(key));
  }

  function validateRequest(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      throw new Error('Solicitud de instalación inválida.');
    }
    if (!sameKeys(value, ALLOWED_REQUEST_KEYS)) {
      throw new Error('La solicitud contiene campos no autorizados.');
    }
    if (value.schema_version !== '1.0.0' || value.mode !== 'explicit') {
      throw new Error('Contrato de instalación incompatible.');
    }
    if (!Array.isArray(value.assets) || value.assets.length < 1 || value.assets.length > MAX_ASSETS) {
      throw new Error('La solicitud debe contener entre 1 y 100 audios.');
    }

    const seen = new Set();
    const assets = value.assets.map(row => {
      if (!row || typeof row !== 'object' || Array.isArray(row) || !sameKeys(row, ALLOWED_ASSET_KEYS)) {
        throw new Error('Activo de instalación inválido.');
      }
      const officialCode = String(row.official_code || '').trim();
      const language = String(row.language || '').trim().toUpperCase();
      if (!officialCode || !LANGUAGES.has(language)) {
        throw new Error('Identidad de audio inválida.');
      }
      const key = officialCode + ':' + language;
      if (seen.has(key)) throw new Error('La solicitud contiene audios duplicados.');
      seen.add(key);
      return { official_code: officialCode, language };
    });

    return {
      schema_version: '1.0.0',
      mode: 'explicit',
      assets
    };
  }

  function validateResponse(value, requestedAssets) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || !sameKeys(value, ALLOWED_RESPONSE_KEYS)) {
      throw new Error('Respuesta del instalador nativo inválida.');
    }
    if (value.schema_version !== '1.0.0' || !ALLOWED_STATUSES.has(value.status)) {
      throw new Error('Respuesta del instalador nativo incompatible.');
    }
    for (const key of ['requested_assets', 'installed_assets', 'failed_assets']) {
      if (!Number.isInteger(value[key]) || value[key] < 0) {
        throw new Error('Conteo inválido en respuesta del instalador.');
      }
    }
    if (value.requested_assets !== requestedAssets) {
      throw new Error('El instalador respondió para una solicitud distinta.');
    }
    if (value.installed_assets + value.failed_assets > value.requested_assets) {
      throw new Error('Conteos imposibles en respuesta del instalador.');
    }
    if (typeof value.runtime_refresh_required !== 'boolean') {
      throw new Error('Falta estado de actualización runtime.');
    }
    return {
      schema_version: '1.0.0',
      status: value.status,
      requested_assets: value.requested_assets,
      installed_assets: value.installed_assets,
      failed_assets: value.failed_assets,
      runtime_refresh_required: value.runtime_refresh_required
    };
  }

  function androidHost() {
    const bridge = window.EEVAndroidAudioInstaller;
    if (!bridge || typeof bridge.installExplicitAudioSelection !== 'function') return null;
    return {
      async installExplicitAudioSelection(request) {
        const raw = bridge.installExplicitAudioSelection(JSON.stringify(request));
        if (typeof raw !== 'string') throw new Error('El instalador Android devolvió una respuesta inválida.');
        try {
          return JSON.parse(raw);
        } catch {
          throw new Error('El instalador Android devolvió una respuesta ilegible.');
        }
      }
    };
  }

  function host() {
    const candidate = window.__EEV_NATIVE_AUDIO_HOST || androidHost();
    if (!candidate || typeof candidate.installExplicitAudioSelection !== 'function') return null;
    return candidate;
  }

  async function install(request) {
    const cleanRequest = validateRequest(request);
    const nativeHost = host();
    if (!nativeHost) throw new Error('El instalador nativo todavía no está disponible en este contenedor.');
    const raw = await nativeHost.installExplicitAudioSelection(cleanRequest);
    return validateResponse(raw, cleanRequest.assets.length);
  }

  window.EEVNativeAudioInstallBridge = Object.freeze({
    schemaVersion: '1.0.0',
    maxAssets: MAX_ASSETS,
    available: () => Boolean(host()),
    validateRequest,
    install
  });
})();
