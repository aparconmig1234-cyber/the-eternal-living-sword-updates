(()=>{
  function run(){
    const hash=String(location.hash||'').replace(/^#/,'');
    if(!hash.startsWith('eev-')) return;
    const shell=window.__EEV_VISUAL_SHELL;
    if(!shell) return;
    const actions={
      'eev-reproductor':()=>shell.openMessages({audioMode:true,skipCover:true}),
      'eev-solo-leer':()=>shell.openMessages({skipCover:true}),
      'eev-biblioteca':()=>shell.openMessages({view:'all',skipCover:true}),
      'eev-libros':()=>shell.openMessages({view:'books',skipCover:true}),
      'eev-audio':()=>shell.openMessages({audioMode:true,skipCover:true}),
      'eev-buscar':()=>shell.openModule('concordancia'),
      'eev-concordancia':()=>shell.openModule('concordancia'),
      'eev-favoritos':()=>shell.openModule('favoritos'),
      'eev-cuenta':()=>shell.openModule('cuenta')
    };
    const fn=actions[hash];
    if(!fn) return;
    history.replaceState(null,'',location.pathname);
    requestAnimationFrame(fn);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(run,0));
  else setTimeout(run,0);
})();
/*EEV-PAD:00000009xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*/
