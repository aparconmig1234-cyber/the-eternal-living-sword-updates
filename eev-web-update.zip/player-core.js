(() => {
  'use strict';

  let globalPlayer = null;
  const LOCAL_PROTOCOLS = new Set(['file:', 'content:', 'app:', 'capacitor:']);

  function assertInstalledLocalSource(raw) {
    const value = String(raw ?? '').trim();
    if (!value) throw new Error('Falta la ruta local del audio instalado.');
    if (/^\/\//u.test(value)) throw new Error('Una fuente de red no puede usarse para reproducción normal.');
    const match = value.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):/u);
    const scheme = match ? match[1].toLowerCase() + ':' : null;
    if (scheme && !LOCAL_PROTOCOLS.has(scheme)) throw new Error('Sólo se permite audio instalado localmente.');
    return value;
  }

  function requireAsset(asset) {
    if (!asset || typeof asset !== 'object') throw new Error('Activo de audio inválido.');
    if (!String(asset.official_code || '').trim()) throw new Error('Falta official_code.');
    if (!['eng','spn','bilingual'].includes(asset.profile)) throw new Error('Perfil de audio inválido.');
    if (asset.profile === 'bilingual' && asset.sync_map_verified !== true) {
      throw new Error('El modo bilingüe requiere un mapa de sincronización verificado.');
    }
    assertInstalledLocalSource(asset.local_path);
    if (!Number.isInteger(asset.verified_file_bytes) || asset.verified_file_bytes <= 0) {
      throw new Error('El audio local no tiene tamaño verificado.');
    }
    if (!/^[a-f0-9]{64}$/iu.test(String(asset.verified_file_sha256 || ''))) {
      throw new Error('El audio local no tiene SHA-256 verificado.');
    }
  }

  function parseStored(raw) {
    if (!raw) return null;
    try {
      const value = JSON.parse(raw);
      if (!Number.isFinite(value.logical_position_ms) || value.logical_position_ms < 0) return null;
      return value;
    } catch {
      return null;
    }
  }

  function parseHistory(raw) {
    if (!raw) return [];
    try {
      const value = JSON.parse(raw);
      if (!Array.isArray(value)) return [];
      return value
        .filter(row =>
          row && typeof row === 'object' &&
          String(row.official_code || '').trim() &&
          ['eng','spn','bilingual'].includes(row.profile) &&
          Number.isFinite(row.logical_position_ms) &&
          row.logical_position_ms >= 0
        )
        .map(row => ({
          official_code:String(row.official_code).trim(),
          product_identity_id:row.product_identity_id ?? null,
          profile:row.profile,
          logical_position_ms:Math.max(0,Math.round(row.logical_position_ms)),
          last_played_at:String(row.last_played_at || ''),
          play_count:Number.isInteger(row.play_count) && row.play_count >= 0 ? row.play_count : 0
        }));
    } catch {
      return [];
    }
  }

  function createHtmlAudioDriver(mediaElement) {
    if (!mediaElement || typeof mediaElement.addEventListener !== 'function') {
      throw new Error('Se requiere un elemento de audio válido.');
    }
    return {
      async loadLocal(localPath) {
        const source = assertInstalledLocalSource(localPath);
        const resolved = new URL(source, document.baseURI);
        if (!LOCAL_PROTOCOLS.has(resolved.protocol)) throw new Error('La ruta resuelta no pertenece al almacenamiento local.');
        await new Promise((resolve, reject) => {
          const loaded = () => cleanup(resolve);
          const failed = () => cleanup(() => reject(new Error('El audio local no se pudo abrir.')));
          const cleanup = done => {
            mediaElement.removeEventListener('loadedmetadata', loaded);
            mediaElement.removeEventListener('error', failed);
            done();
          };
          mediaElement.addEventListener('loadedmetadata', loaded, { once:true });
          mediaElement.addEventListener('error', failed, { once:true });
          mediaElement.src = resolved.href;
          mediaElement.load();
        });
      },
      play: () => mediaElement.play(),
      pause: () => mediaElement.pause(),
      seek: ms => { mediaElement.currentTime = Math.max(0, Number(ms) || 0) / 1000; },
      positionMs: () => Math.max(0, Number(mediaElement.currentTime) || 0) * 1000,
      durationMs: () => Number.isFinite(mediaElement.duration) ? mediaElement.duration * 1000 : 0,
      setRate: rate => { mediaElement.playbackRate = rate; },
      setVolume: volume => { mediaElement.volume = volume; },
      on(event, handler) {
        mediaElement.addEventListener(event, handler);
        return () => mediaElement.removeEventListener(event, handler);
      }
    };
  }

  class Player {
    constructor({ mediaElement, storage = window.localStorage, namespace = 'eternal-living-sword.player.v1', historyLimit = 100 }) {
      this.driver = createHtmlAudioDriver(mediaElement);
      this.storage = storage;
      this.namespace = namespace;
      if (!Number.isInteger(historyLimit) || historyLimit < 1 || historyLimit > 500) {
        throw new Error('Límite de historial inválido.');
      }
      this.historyLimit = historyLimit;
      this.session = null;
      this.state = 'idle';
      this.suspendPersistence = false;
      this.unsubscribers = [
        this.driver.on('timeupdate', () => this.persist()),
        this.driver.on('pause', () => this.persist()),
        this.driver.on('ended', () => { this.state = 'ended'; this.persist(); })
      ];
    }
    resumeKey(code, profile) {
      return this.namespace + ':resume:' + code + ':' + profile;
    }

    historyKey() {
      return this.namespace + ':history';
    }
    getHistory() {
      return parseHistory(this.storage.getItem(this.historyKey()))
        .slice(0,this.historyLimit)
        .map(row => ({...row}));
    }
    writeHistory(rows) {
      this.storage.setItem(this.historyKey(),JSON.stringify(rows.slice(0,this.historyLimit)));
    }
    recordPlaybackStart() {
      if (!this.session) return;
      const history=this.getHistory();
      const index=history.findIndex(row =>
        row.official_code===this.session.official_code && row.profile===this.session.profile
      );
      const previous=index>=0 ? history[index] : null;
      const measured=Math.max(0,Math.round(Number(this.driver.positionMs())||0));
      const entry={
        official_code:this.session.official_code,
        product_identity_id:this.session.product_identity_id,
        profile:this.session.profile,
        logical_position_ms:measured,
        last_played_at:new Date().toISOString(),
        play_count:(previous?.play_count || 0)+1
      };
      this.writeHistory([
        entry,
        ...history.filter(row => !(row.official_code===entry.official_code && row.profile===entry.profile))
      ]);
    }
    updateHistoryPosition() {
      if (!this.session) return;
      const history=this.getHistory();
      const index=history.findIndex(row =>
        row.official_code===this.session.official_code && row.profile===this.session.profile
      );
      if (index<0) return;
      history[index]={
        ...history[index],
        logical_position_ms:Math.max(0,Math.round(Number(this.driver.positionMs())||0))
      };
      this.writeHistory(history);
    }
    removeHistory(officialCode,profile) {
      const code=String(officialCode||'').trim();
      const normalizedProfile=String(profile||'').trim();
      const history=this.getHistory().filter(row =>
        !(row.official_code===code && row.profile===normalizedProfile)
      );
      this.writeHistory(history);
      return history.map(row => ({...row}));
    }
    clearHistory() {
      this.writeHistory([]);
      return [];
    }
    async load(asset) {
      requireAsset(asset);
      if (this.session) this.persist();
      this.state = 'loading_local';
      this.suspendPersistence = true;
      try {
        await this.driver.loadLocal(asset.local_path);
        const stored = parseStored(this.storage.getItem(this.resumeKey(asset.official_code, asset.profile)));
        const restoreMs = stored?.logical_position_ms || 0;
        this.driver.seek(restoreMs);
        if (stored?.rate && Number.isFinite(stored.rate)) this.driver.setRate(stored.rate);
        const volume = stored?.volume ?? 1;
        this.driver.setVolume(volume);
        this.session = {
          official_code:String(asset.official_code),
          product_identity_id:asset.product_identity_id ?? null,
          profile:asset.profile,
          local_path:asset.local_path,
          verified_file_sha256:String(asset.verified_file_sha256).toLowerCase(),
          verified_file_bytes:asset.verified_file_bytes,
          logical_position_ms:restoreMs,
          rate:stored?.rate || 1,
          volume
        };
        this.state = 'paused';
      } finally {
        this.suspendPersistence = false;
      }
      this.persist();
      return this.snapshot();
    }
    async play() {
      if (!this.session) throw new Error('No hay audio local cargado.');
      await this.driver.play();
      this.state = 'playing';
      this.recordPlaybackStart();
      return this.snapshot();
    }
    pause() {
      if (!this.session) return this.snapshot();
      this.driver.pause();
      this.state = 'paused';
      this.persist();
      return this.snapshot();
    }
    seek(ms) {
      if (!this.session) throw new Error('No hay audio local cargado.');
      this.driver.seek(Math.max(0, Math.round(Number(ms) || 0)));
      this.persist();
      return this.snapshot();
    }
    setRate(rate) {
      if (!this.session) throw new Error('No hay audio local cargado.');
      const next=Number(rate);
      if (!Number.isFinite(next) || next<0.5 || next>3) throw new Error('Velocidad inválida.');
      this.driver.setRate(next); this.session.rate=next; this.persist(); return this.snapshot();
    }
    setVolume(volume) {
      if (!this.session) throw new Error('No hay audio local cargado.');
      const next=Number(volume);
      if (!Number.isFinite(next) || next<0 || next>1) throw new Error('Volumen inválido.');
      this.driver.setVolume(next); this.session.volume=next; this.persist(); return this.snapshot();
    }
    persist() {
      if (this.suspendPersistence || !this.session) return;
      const measured=Math.max(0,Math.round(Number(this.driver.positionMs())||0));
      this.session.logical_position_ms=measured;
      this.storage.setItem(this.resumeKey(this.session.official_code,this.session.profile),JSON.stringify({
        logical_position_ms:measured,
        rate:this.session.rate,
        volume:this.session.volume,
        updated_at:new Date().toISOString()
      }));
      this.updateHistoryPosition();
    }
    snapshot() {
      return {
        state:this.state,
        session:this.session ? {...this.session} : null,
        duration_ms:this.driver.durationMs(),
        network_source_allowed:false,
        runtime_source:'installed_local_file_only'
      };
    }
    destroy() {
      this.pause();
      for (const unsubscribe of this.unsubscribers.splice(0)) unsubscribe();
      if (globalPlayer===this) globalPlayer=null;
    }
  }

  window.EEVPlayerCore = Object.freeze({
    assertInstalledLocalSource,
    createGlobalPlayer(options) {
      if (globalPlayer) throw new Error('Ya existe un reproductor global activo.');
      globalPlayer = new Player(options);
      return globalPlayer;
    },
    getGlobalPlayer() { return globalPlayer; }
  });
})();
